
import 'package:flutter/material.dart';
import 'package:mdi/mdi.dart';




void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,

      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);


  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}





class _MyHomePageState extends State<MyHomePage> {



 getColor(indexQ,index){
   
   if(isPressed[indexQ][index]&&index == correct[indexQ]){
     return Colors.green;
   }
   else if(isPressed[indexQ][index]){
     return Colors.red;
   }
   else{
     return Colors.white70;
   }
     
  
  
}

int val = -1;




var isPressed = <List> [
  [false,false,false,false],
  [false,false,false,false],
  [false,false,false,false],
  [false,false,false,false]];

var icons = <MdiIconData> [Mdi.alphaACircle,Mdi.alphaBCircle,Mdi.alphaCCircle,Mdi.alphaDCircle];


var answers =  <List> [
  ["Love","Reality","Space","Time"],
  ["Gravitonium","Vibranium","Adamantium","Scabrite"],
  ["Sokovia","Wakanda","Krakoa","Symkaria"],
  ["Spiderman","Black Widow","Tony Stark","Captain America"]
];


var questions = <String> [
  "Which of these is NOT an infinity stone?",
  "What is Captain America's shield made out of?",
  "What country are Scarlet Witch and Quicksilver from?",
  "Who can lift Thor's hammer?"];

 var correct = <int> [0,1,0,3];





  @override
  Widget build(BuildContext context) {



    return Scaffold(
      backgroundColor: Colors.indigo[900],




        body: Column(
          children: [
            Expanded(

              child: ListView.separated(

                shrinkWrap: true,


                itemBuilder: (context, indexQ) {


                return Padding(
                     padding: const EdgeInsets.only(top: 50,bottom: 10),


                     child: Column(
                       mainAxisAlignment: MainAxisAlignment.center,
                       crossAxisAlignment: CrossAxisAlignment.center,





                       children: [




                         Padding(
                           padding: const EdgeInsets.only(left: 50.0,right: 50,bottom: 25),
                           child: Text(questions[indexQ],style: const TextStyle(
                             fontWeight: FontWeight.bold,
                             color: Colors.yellow,
                             fontSize: 20,


                           ),
                           ),
                         ),



                         ListView.separated(

                           shrinkWrap: true,
                           itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(left: 100, right: 100),

                            child: ListTile(

                              leading: Icon(icons[index], size: 50,
                                  color: getColor(indexQ, index)),



                              title: Text(answers[indexQ][index],style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: getColor(indexQ, index)),
                              ),


                              //tileColor: isPressed[index]? Colors.red: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(25),),

                              onTap: () async {
                                setState(() {
                                  isPressed[indexQ] = [false, false, false, false];

                                  isPressed[indexQ][index] = !isPressed[indexQ][index];
                                });
                              },

                              tileColor: Colors.indigo[600],


                            ),
                          );




                  }


                          ,
                          separatorBuilder: (BuildContext context, int index) =>
                          const SizedBox(
                            height: 10,),
                          itemCount: 4,),
                       ],
                     ),
                   );}
                ,itemCount: 4,
                separatorBuilder: (BuildContext context, int index) =>
                const SizedBox(
                  height: 10,),

              ),
            ),
          ],
        ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.indigo[700],
        elevation: 10,
        onPressed: (){
          setState(() {
    isPressed =  [
    [false,false,false,false],
    [false,false,false,false],
    [false,false,false,false],
    [false,false,false,false]];


    }




          );},
        child: const Icon(Icons.refresh),



      ),





    );
  }


  }

