package com.example.task5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
