package com.example.dryrun2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
