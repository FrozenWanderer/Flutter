import 'package:flutter/material.dart';


class Screen extends StatelessWidget {

  const Screen({Key? key}) : super(key: key);

  final List<String>imagePath= const [
    'https://cdn.cnn.com/cnnnext/dam/assets/220225095200-ukraine-russia-conflict-022522-super-tease.jpg',
    'https://cdn.cnn.com/cnnnext/dam/assets/220225180808-kyiv-explosion-0226-super-tease.jpg',
    'https://imagez.tmz.com/image/2b/16by9/2022/02/25/2b31d8b0925b400882e2a4bf7e0c3f23_xl.jpg',
    'https://cdn.cnn.com/cnnnext/dam/assets/220225095200-ukraine-russia-conflict-022522-super-tease.jpg',
    'https://cdn.cnn.com/cnnnext/dam/assets/220225180808-kyiv-explosion-0226-super-tease.jpg',
    'https://imagez.tmz.com/image/2b/16by9/2022/02/25/2b31d8b0925b400882e2a4bf7e0c3f23_xl.jpg',
    'https://cdn.cnn.com/cnnnext/dam/assets/220225180808-kyiv-explosion-0226-super-tease.jpg',
    'https://imagez.tmz.com/image/2b/16by9/2022/02/25/2b31d8b0925b400882e2a4bf7e0c3f23_xl.jpg'
  ];
  final List<String>text= const [
    'Fly Your Name for Free Around the Moon on NASA',
    'Videos show explosions and gunfire around Ukrainian capital - CNN',
    'Kylie Jenner Back in Action Just 3 Weeks After Giving Birth - TMZ',
    'Fly Your Name for Free Around the Moon on NASA',
    'Videos show explosions and gunfire around Ukrainian capital - CNN',
    'Kylie Jenner Back in Action Just 3 Weeks After Giving Birth - TMZ',
    'Videos show explosions and gunfire around Ukrainian capital - CNN',
    'Kylie Jenner Back in Action Just 3 Weeks After Giving Birth - TMZ'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
