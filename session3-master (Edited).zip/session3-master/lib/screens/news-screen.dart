import 'package:flutter/material.dart';
import 'Screen.dart';
import 'details.dart';


class NewsScreen extends Screen {


  @override
   build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.white,
          title: Text(
            'News',
            style: TextStyle(
                color: Colors.black
            ),
          ),
        ),
        body: Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child:ListView.separated(
              itemCount: imagePath.length,
              itemBuilder: (context,index)
              {
                return GestureDetector(
                  onTap: ()
                  {
                    Navigator.push(context, MaterialPageRoute(
                        builder: (context)
                        {
                          return DetailsScreen(index);
                        }
                    ));
                  },
                  child: Row(
                    children: [
                      Image(
                        image: NetworkImage(imagePath[index]),
                        height: 100,),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                          child: Text(text[index]))
                    ],
                  ),
                );

              },
              separatorBuilder: (BuildContext context, int index) =>SizedBox(height: 10,),))
    );
  }
}
