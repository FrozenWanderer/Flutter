import 'package:flutter/material.dart';
import 'Screen.dart';

class DetailsScreen extends Screen {
  final int index;

   DetailsScreen(this.index);


  @override
   build(BuildContext context) {
    return Scaffold(
        body:SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image(
                  image: NetworkImage(imagePath[index]),
                  height: 400,
                  fit:BoxFit.cover
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      text[index],
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      '2022-04-06',
                      style: TextStyle(
                          fontSize: 14
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Fly Your Name for Free Around the Moon on NASA Fly Your Name for Free Around the Moon on NASA Fly Your Name for Free Around the Moon on NASA',
                      style: TextStyle(
                          fontSize: 14
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }
}