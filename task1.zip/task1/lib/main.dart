import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Thanos Fan App',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Thanos Fan Page'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);



  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {




  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,

      body: Container(
        decoration: BoxDecoration(
          //Load Image
          image: DecorationImage(
            image: AssetImage('images/Thanos.jpg'), fit:BoxFit.cover,
          ),
        ),


        //Applying Gradient to Image
        child: Container(

          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomRight,
              colors: [Colors.black87,Colors.black12],

            ),
          ),
          child: Padding(
            padding: EdgeInsets.all(20),

    child: Column(

    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget> [
        Text( "Thanos", style: TextStyle( color: Colors.yellow, fontWeight: FontWeight.bold, fontSize: 50),),

        Row( children: <Widget>[
            Text("30 Videos", style: TextStyle(color: Colors.grey, fontSize: 16),),

            SizedBox(width: 50,),

            Text("120K Subscribers", style: TextStyle(color: Colors.grey, fontSize: 16),


            )

          ],

        ),
        SizedBox(height: 20,),

        Text("From his birth on Saturn's moon of Titan, Thanos was always an outsider. He carries a Deviants gene, which causes his gruesome and misshapen appearance, with purple, rugged skin. He was born among the last sons of Titan's original colonists: Mentor and Sui-San.", style: TextStyle(color: Colors.grey, height: 1.4),
        ),
        SizedBox(height: 20,),








      ],





    ),
          ),





        ),





      )
    );
  }
}
