import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:task2/my_icons_icons.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
const MyApp({Key? key}) : super(key: key);

// This widget is the root of your application.
@override
Widget build(BuildContext context) {
  return MaterialApp(
    title: 'Thanos Story',
    theme: ThemeData(

      primarySwatch: Colors.blue,
    ),
    home: const MyHomePage(title: 'Thanos Story'),
    debugShowCheckedModeBanner: false,
  );
}
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);



  final String title;

  @override
  State<MyHomePage> createState() => _MyhomePageState();
}

class _MyhomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {



    return Container(
      //Make Scaffold Gradient

        decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.deepPurple,
            Colors.purple,
            Colors.deepOrange,
            Colors.orange,
            Colors.yellow,
            Colors.yellowAccent
          ]
        )
    ),

      child: Scaffold(
        //Background Transparent
        backgroundColor: Colors.transparent,

        //Center The Post

        body: Center(



          //Post Body

          child: Container(
            //Post boundaries and background color

            height: 405,
            width: 320,

            decoration: BoxDecoration(

              color: Colors.white,
              border: Border.all(
                color: Colors.grey,
              ),


            ),

            child: Column(
              children: [
                //Avatar + Name + DownArrow
                ListTile(
                  leading: const CircleAvatar(
                    backgroundImage: AssetImage("images/Thanos.webp"),

                  ),


                  title: Row(
                    children: const [
                      Text("Thanos", style: TextStyle(
                        fontWeight: FontWeight.bold,

                      ), ),
                      SizedBox(width: 150,),
                      Icon(Icons.keyboard_arrow_down,color: Colors.grey,),
                    ],

                  ),
                ),


                //Post Title

               const Text("Finally, a grateful universe 🙏 ☺",
                  style: TextStyle(
                  color: Colors.black,
                    fontWeight: FontWeight.w300,
                    fontSize: 16
                ),),

                const SizedBox(height: 10,),


                //Post Image

                Container(

                  width: 230,
                  height: 250,

                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.grey,
                    ),
                    image: const DecorationImage(
                      image: AssetImage("images/Thanos_Resting.jpg"),fit: BoxFit.fill
                    ),


                  ),

                ),

                const SizedBox(height: 10,),

                //Separator

                const Divider(color: Colors.grey,
                  endIndent: 5,
                  indent: 5,
               thickness: 0.5, ),

                const SizedBox(height: 5,),

                //Like + Comment + Share

                Row(
                  children: const [
                    SizedBox(width: 28,),
                    Icon(Icons.thumb_up,color: Colors.black,),
                    SizedBox(width: 3,),
                    Text("Like"),

                    SizedBox(width: 30,),
                    Icon(Icons.comment,color: Colors.black,),
                    SizedBox(width: 3,),
                    Text("Comment"),

                    SizedBox(width: 30,),
                    Icon(MyIcons.share),

                    SizedBox(width: 3,),
                    Text("Share"),




                  ],

                  ),



              ],
            ),


          ),

        ),

      ),
    );
  }
}
