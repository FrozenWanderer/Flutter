
import 'package:flutter/material.dart';




void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Thanos Cult login',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.yellow,
      ),
      home: const MyHomePage(title: 'Thanos Cult Login'),
    );
  }
}

 buildLogo(){
   return const Image(image: AssetImage("images/thanos.png"),height: 300);

 }

 Widget buildUsernameField() => Padding(
   padding: const EdgeInsets.fromLTRB(25,10,25,10),


   child: TextField(

     keyboardType: TextInputType.emailAddress,





     controller: email,





     decoration: const InputDecoration(
       suffixIcon: Icon(Icons.mail_outline),
       filled: true,
       fillColor: Colors.white70,





       floatingLabelBehavior: FloatingLabelBehavior.auto,
       hintText: "Email",

       focusedBorder: OutlineInputBorder(


           borderRadius: BorderRadius.all(Radius.circular(25))
       ),
       enabledBorder: OutlineInputBorder(
         borderRadius: BorderRadius.only(topRight: Radius.circular(25),
             bottomLeft: Radius.circular(25)

         ),



       ),



     ),
   ),
 );



Widget buildPasswordField() => Padding(
  padding: const EdgeInsets.fromLTRB(25,5,25,25),
  child: TextField(


    controller: password,
      obscureText: true,



    decoration: const InputDecoration(
      suffixIcon: Icon(Icons.password),

      hintText:"Password",
      filled: true,
      fillColor: Colors.white70,
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(25))
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.only(topRight: Radius.circular(25),
            bottomLeft: Radius.circular(25)

        ),




      ),



    ),
  ),
);


Widget buildButton() =>
    Padding(
      padding: const EdgeInsets.fromLTRB(100, 0, 100, 0),
      child: ElevatedButton(onPressed:(){

        print("Email: $email");
        print("Password: $password");

        email.clear();
        password.clear();


      } , child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Text("LOGIN"),
        ],

      ),
        style: ButtonStyle(
            shape: MaterialStateProperty.all(
                const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(25)),
                ),
            ),
        ),),
    );








class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);


  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

TextEditingController email = TextEditingController();
TextEditingController password = TextEditingController();

class _MyHomePageState extends State<MyHomePage> {
  @override




  Widget build(BuildContext context) {

    final isKeyboard = MediaQuery.of(context).viewInsets.bottom != 0;

    return Scaffold(

      backgroundColor: Colors.brown.shade900,

      body: Center(

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            if (!isKeyboard) buildLogo(),

            buildUsernameField(),

            buildPasswordField(),

            buildButton(),












          ],




        ),
      ),

    );
  }
}
