import 'package:flutter/material.dart';
import 'Screen.dart';


class DetailsScreen extends Screen {


  final int index;

  DetailsScreen(this.index);






  @override
  build(BuildContext context) {
    return Scaffold(

      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,


            children: [
              Image(image: AssetImage(
                  image[index]
              ),height: 300 ,width:500,fit: BoxFit.cover,),



              Container(
                width: 500,

                decoration: BoxDecoration(
                    color: Colors.orange

                )
                ,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Center(
                    child: Text(titleText[index],
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      )

                      ,),
                  ),
                ),
              ),

              Material(
                elevation: 5,
                child: Container(
                  width: 500,
                  height: 20,
                  decoration: BoxDecoration(
                      color: Colors.yellow

                  )
                  ,

                  child: Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: Text(date[index],style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w700
                    ),),
                  ),
                ),
              ),

              Center(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(bodyText[index],style: TextStyle(
                    color: Colors.black,
                  ),),
                ),
              ),


            ],




          ),
        ),
      ),




    );
  }
}