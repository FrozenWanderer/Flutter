import 'package:flutter/material.dart';



class Screen extends StatelessWidget {
  const Screen({Key? key}) : super(key: key);


  final List<String>image = const [
    'images/1.jpg',
    'images/2.jpg',
    'images/3.jpg',
    'images/4.jpg',
    'images/6.jpg',
    'images/7.jpg'





  ];

  final List<String>titleText = const [
    'Who is Spider-Man?',
    'Spider-man Identity Revealed!',
    'Strange Things Happen in WestView.',
    'Iron-man Saved Us!',
    'Half of the Universe is Gone Now!',
    'Thanos is Here.',



  ];

  final List<String>bodyText = const [
    'Nothing but a coward behind his mask.',
    'With Mysterio’s shocking final testament, a video doctored to reveal Spider-Man’s secret identity and implicate Peter in his death, Peter’s friends and family are thrown into danger. While their proximity to Peter always made them vulnerable.',
    'FBI agent Jimmy Woo traveled to Westview in search of a missing person, who was living there as part of the Witness Protection Program. He later requested S.W.O.R.D. to lend him one of their imaging drones, where Captain Monica Rambeau was sent to help. Questioning the Eastview police officers that were nearby, the two learned that the town had been mysteriously forgotten, and that something was preventing them from entering.',
    'Iron Man died to save the universe, and it might have been necessary to save the galaxy.',
    'Thanos snapped his finger and wiped out half of all life in the universe.',
    'Thanos searching through the galaxy for the six Infinity Stones. Thanos’ goal is to eliminate half the life in the universe using the stones’ incredible power, but he doesn’t do that for no reason. Thanos believes that the only way to save the universe is to thin out the life in it, to eliminate conflict for resources that would otherwise lead to death and suffering.'
  ];



  final List<String>date = const [

    'December 17, 2021',
    'June 26, 2019',
    'January 15, 2021',
    'April 26, 2019',
    'April 27, 2018',
    'April 27, 2018',

  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
