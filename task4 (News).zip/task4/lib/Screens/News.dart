import 'package:flutter/material.dart';
import 'Details.dart';
import 'Screen.dart';




class NewsScreen extends Screen {







  @override
  build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.orange,


          centerTitle: true,


          title: const Text("News", style: TextStyle(color: Colors.black),),

        ),

        body:
        ListView.separated(itemBuilder: (context,index) {

          return GestureDetector(

            onTap: (){

              Navigator.push(context, MaterialPageRoute(builder: (context){

                return DetailsScreen(index);


              }
              ));

            },




            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Material(
                borderRadius: BorderRadius.only(

                  topLeft: Radius.circular(25),
                  bottomLeft: Radius.circular(25)

                ),
                elevation: 5,
                child: Row(


                  children: [





                    ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image(image: AssetImage(image[index]),height: 100, width: 150,fit: BoxFit.fill,)),

                    const SizedBox(width: 10),


                    Expanded(
                        child: Text(titleText[index]))
                  ],





                ),
              ),
            ),
          );



        },


          itemCount: 6,
          separatorBuilder: (BuildContext context,int index) => const SizedBox(height: 2,),)


    );




  }
}