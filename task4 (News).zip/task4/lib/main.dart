import 'package:flutter/material.dart';

import 'Screens/News.dart';



void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'News',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyNewsPage(title: 'News'),
    );
  }
}




class MyNewsPage extends StatefulWidget {
  const MyNewsPage({Key? key, required this.title}) : super(key: key);


  final String title;



  @override
  State<MyNewsPage> createState() => _MyNewsPageState();


}



class _MyNewsPageState extends State<MyNewsPage> {

  @override
  Widget build(BuildContext context) {

    return NewsScreen();


  }
  }

















